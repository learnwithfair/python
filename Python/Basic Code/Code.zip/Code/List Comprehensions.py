num = [1,2,3,4,5,6]
print("List : ",num)
result = [x*x for x in num]
print("Square value : ",result)
result = [x for x in num if x%2==0]
print("Filter of the Even number : ",result)