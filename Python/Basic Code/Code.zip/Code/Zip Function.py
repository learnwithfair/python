rolls = [101,102,103,104,105,106]
names = ["Rahatul islam","Suhanur islam","Imran Hossain","Masud Rana","Anisul Islam","Bappy Chawdhary"]
result = list(zip(rolls,names,"ABABAB"))
print(result)