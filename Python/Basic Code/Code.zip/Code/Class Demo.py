#Class
class studenet:
    name = ""
    roll = ""
    gpa = ""
#Constructor
    def __init__(self,name,roll,gpa):
        self.name = name
        self.roll = roll
        self.gpa = gpa
        self.display()
#Function
    def display(self):
        print("Name : "+self.name+"\nRoll : "+self.roll+"\nGPA : "+self.gpa+"\n")
student1 = studenet("Rahatul Islam","101","3.92")
student2 = studenet("Suhanur Islam","102","3.82")
student3 = studenet("Imran Hosssain","103","3.50")
