n=0
print("\nBreak Statement")
while n<=100:
    if n==50:
        break
    print(n)
    n = n+10
print("\nContinue Statement")
n=0
while n<=100:
    if n==50:
        n = n + 10
        continue

    print(n)
    n = n + 10