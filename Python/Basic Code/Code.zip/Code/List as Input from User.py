n = input("Enter any numbers : ")
list = n.split()
sum = 0
for x in list:
    sum = sum + int(x)
print("Summation of the list : ",sum)