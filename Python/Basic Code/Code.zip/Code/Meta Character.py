import re
pattern = r"ice(-)?cream"
if re.match(pattern,"icecream"):
    print("Matched")
else:print("Not Matched")