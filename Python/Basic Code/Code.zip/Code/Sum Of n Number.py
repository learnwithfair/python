n = int(input("Enter any Number : "))
i = 1
sum =0
while i<=n:
    sum = sum+i
    i= i+1
print("Summation of n Number : ",sum)
