'''Pass Fail Programme'''
while True:
    number = int(input("Enter your Number : "))
    if number>100:
        print("Invalid Result")
    elif number<0:
        print("Invalid Result")
    elif number>=80:
        print("First Division")
    elif number>=60:
        print("Second Division")
    elif number>=33:
        print("Third Division")
    else:
        print("Fail")

