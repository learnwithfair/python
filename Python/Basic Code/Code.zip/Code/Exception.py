try:
    num1 = int(input("Enter First Number : "))
    num2 = int(input("Enter Second number : "))
    result = num1 / num2
    print(num1, "/", num2, " : ", result)
except (ZeroDivisionError,TypeError,ValueError) as e:
    print(e)
finally:
    print("Thank you")