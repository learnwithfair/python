import re
pattern = r"[aeiou,AEIOU]"
text = "University"
if re.match(pattern,text):
    print("Matched")
else:
    print("Not Matched")
pattern = r"[0-9]"
text = "University9"
if re.match(pattern,text):
    print("Matched")
else:
    print("Not Matched")
