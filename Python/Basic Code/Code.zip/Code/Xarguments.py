#It works as Tuples
def add(*numbers):
    sum =0
    for num in numbers:
        sum = sum + num
    print("Summation : ",sum)

add(20,30)
add(10,20,30)
add(10,20,30,40)
add(1,2,3,4,5,6)
