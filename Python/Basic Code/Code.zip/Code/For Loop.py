n = int(input("How many term : "))
sum = 0
number = range(1,n+1)
for x in number:
    sum = sum + x
print("Summation of the 1 to ",n," term : ",sum)