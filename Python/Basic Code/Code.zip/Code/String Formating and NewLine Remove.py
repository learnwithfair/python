num1 = 20
num2 = 30
print("Summation :",end=" ")
print(f"{num1} + {num2} = {num1+num2}")