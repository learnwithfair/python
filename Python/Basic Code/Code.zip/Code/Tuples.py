tuples1  = (2,3,4,5,2,2)
tuples2  = (
    tuples1,
    "Rahatul Islam",
    "Suhanur Islam"

)
print(tuples1)
print("3rd position Value is : ",tuples1[2])
# tuples[3] = 15 it not possible
print("4rd position Value is : ",tuples1[3])
print("Tuples2 : ",tuples2)