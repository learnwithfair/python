#Guessing Game
from random import randint
import re
n = "raju"
while True:
    n = input("Enter your Guess number limit 1 to 5 : ")
    while n in "raju":
        print("Please Insert your Guess then try again")
        n = input("Enter your Guess number limit 1 to 5 : ")

    pattern=r"[a-z,A-Z]"
    if re.match(pattern,n):
        print("Invalid number. Please enter a valid number.")
    else:
        n = int(n)
        Random_number = randint(1, 5)
        if Random_number == n:
            print("Congratulations! you have won.")
        elif n > 5 or n <= 0:
            print("Invalid number. Please enter a valid number.")
        else:
            print("Sorry! you have loss, Guess number was ", Random_number)
