from area import triangle,rectangular
triangle(10,20)
rectangular(10,20)