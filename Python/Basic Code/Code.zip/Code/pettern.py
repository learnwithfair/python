'''
Pettern
n = 3
*
* *
* * *
'''
n = int(input("How many term : "))
for x in range(1,n+1,1):
    print(x*"* ")