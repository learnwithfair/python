print(30>20);
print(30>=20);
print(30<20);
print(30<=20);
print(30!=20);
print("30"=="30");