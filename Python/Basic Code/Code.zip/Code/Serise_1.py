
#sum of 1+2+3+......+n
n = int(input("Enter last number : "))
sum = 0
number = range(1,n+1,1)
for x in number:
    sum = sum+x
print("Summation of n term series : ",sum)