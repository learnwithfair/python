data = {"Rahat","Suhan","Imran","Raju"}
print(data)
data.pop()#Queue is another called FIFO that means First in First Out
print(data)