
rowNum = int(input("How many number of Row : "))
colNum = int(input("How many number of Column : "))
list = []
for row in range(0,rowNum,1):
    for col in range(0,colNum,1):
        print("A[",row,"][",col,"] : ",end="")
        n = int(input())
        list.append(n)

print("\n\n")
i=0
for row in range(0,rowNum,1):
    for col in range(0,colNum,1):
        print(list[i],end=" ")
        i = i+1
    print("\n")
'''
n = int(input("Enter Value of First Row : "))

matrix = [
    [1,2,3],
    [4,5,6],
    [7,8,9]

]
for row in matrix:
    for col in row:
        print(col,end=" ")
    print("\n")'''