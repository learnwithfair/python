def triangle(h,b):
   print(f"Area of the Triangle : {0.5*h*b}")
def rectangular(a,b):
   print(f"Area of the Triangle : {a*b}")


