#sum of the 1+3+5+....+n ( odd number)
n = int(input("Enter last number : "))
sum = 0
number = range(1,n+1,2)
for x in number:
    sum = sum+x
print("Summation of the odd series 1+3+5+....+",n," = ",sum)