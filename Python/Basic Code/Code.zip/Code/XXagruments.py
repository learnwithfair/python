#It work as Dictonary
def Details(**data):
    print(data,"\n")

Details(id = 101,name = "Rahatul Islam")
Details(id = 102,name = "Suhanur Islam",age = 21)