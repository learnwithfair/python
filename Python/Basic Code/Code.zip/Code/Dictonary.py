dictionary = {
    101 : "Rahatul Islam",
    102 : "Suhanur Islam",
    103 : "Imran Hossain",
    "gpa" : 3.92,
}
print(dictionary)
print("Name : ",dictionary.get(101))
print("GPA : ",dictionary.get("gpa"))
