def fact(n):
    if n==1:
        return 1
    else:
        return n * fact(n-1)
n = int(input("Enter an Integer Number : "))
print("Factorial value of the ",n," is : ",fact(n))