Set = {2,3,4,5,5,4,3,8}
# it can't work by duplicate value

Set2 =set( [3,4,5,6,3])
Set2.add(7)
print(Set2)
Set2.remove(7)
print("Set-1 : ",Set)
print("Set-2 : ",Set2)
#Union
print("Union : ",Set|Set2)
print("Intersection : ",Set&Set2)
print("Deference : ",Set-Set2)