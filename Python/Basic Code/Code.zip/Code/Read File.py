file = open("student.txt","r")
text = file.read()
print(text)
length = len(text)
print("Length of Text : ",length)
'''text = file.readline()
print(text)'''
file.close()