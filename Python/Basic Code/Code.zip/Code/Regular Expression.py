import  re
pattern = r"Colour"
text = re.match(pattern,"Colour favourite colour is Magenta. i also love red colour.")
if text:
    print("Matched")
else:
    print("Not Matched")
text = re.search(pattern,"My favourite Colour is Magenta. i also love red Colour.")
if text:
    print("Start position : ",text.start())
    print("End position : ",text.end())
    print("Start into end position : ",text.span())
else:
    print("Not Searched")
text = re.findall(pattern,"My favourite Colour is Magenta. i also love red Colour.")
if text:
    print(text)
else:
    print("Not Find")
text = re.sub(pattern,"Color","My favourite Colour is Magenta. i also love red Colour.",count=1)
if text:
    print(text)
else:
    print("Not Find")
