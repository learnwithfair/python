def add(x,y):
    sum = x+y
    return sum

a = int(input("Enter a First Number : "))
b = int(input("Enter a Second Number : "))
result = add(a,b)
print("Summation of the ",a," + ",b," : ",result)