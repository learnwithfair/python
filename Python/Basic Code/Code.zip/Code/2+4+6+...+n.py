
#sum of 2+4+6+....+n (even number)
n = int(input("Enter last number : "))
number = range(2,n+1,2)
sum = 0
for x in number:
    sum = sum + x
print("Summation of even number in series 2+4+6+...+",n," = ",sum)