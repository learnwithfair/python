num = [1,2,3,4,5,6]
result = list(map((lambda x : x*x),num))
print("Map : ",result)
result = list(filter((lambda x : x%2==0),num))
print("Filter : ",result)
