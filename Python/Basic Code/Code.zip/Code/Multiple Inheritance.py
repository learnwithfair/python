class A:
    def display(self):
        print("I am inside the A class")
class B:
    def display(self):
        print("I am inside the B class")
class C(A,B):
    def display(self):
        print("I am inside the C class")
class D(C):
    pass
ob1 = D()
ob1.display()