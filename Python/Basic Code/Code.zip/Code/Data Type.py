name = "Md Rahatul Islma"
age = 21
cgpa = 3.95
print("Student Informations")
print("--------------------")
print("Name "+name)
print("Age : ",age)
print("CGPA : ",cgpa)