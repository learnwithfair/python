class A:
    def display1(self):
        print("I am inside the A Class")
class B(A):
    def display2(self):
        print("I am inside the B Class")
class C(B):
    def display3(self):
        print("I am inside the C Class")
ob1 = C()
ob1.display1()
ob1.display2()
ob1.display3()
