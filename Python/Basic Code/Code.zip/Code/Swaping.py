#Swaping 

a = 20
b = 30
tem = a
a = b
b = tem
print("a = ",a,",b = ",b)