from math import *

num1 = float(input("Enter First Number : "))
num2 = float(input("Enter Second Number : "))

result = max(num1,num2)
print("Maximum Number is : ",result)

result = min(num1,num2)
print("Minimum Number is : ",result)
result = abs(num1)
print("Absolut Number is : ",result)
result = sqrt(num1)
print("Square Root Number1 is : ",result)
result = round(num1)
print("Round Number1 is : ",result)
result = floor(num1)
print("Floor Number1 is : ",result)
result = ceil(num1)
print("Ceiling Number1 is : ",result)

