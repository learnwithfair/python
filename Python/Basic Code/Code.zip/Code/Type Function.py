num1 = 20
num2 = 20.45
num3 = "20.59454"
num4 = True
print(type(num1))
print(type(num2))
print(type(num3))
print(type(num4))