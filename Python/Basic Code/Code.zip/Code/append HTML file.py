count = 0
while True:
    if count==1:
        file = open("html_data.html", "a")
        text = input("Enter Next HTML text : ")
        file.write("\n"+text)
        count = 1
    else:
        file = open("html_data.html", "w")
        text = input("Enter any HTML text : ")
        file.write(text)
        count = 1
file.close()