subjects = ["C","C++","JAVA","JAVA Swing","Python","Android"]
print("Value of All list : ",subjects)
print("Value of 4th number in list : ",subjects[4])
print("The list contain value of JAVA : ","JAVA" in subjects)
print("The list contain value of HTML : ","HTML" in subjects)
print("After 2th position all data of list : ",subjects[2:])
print("Before data adding in the list : ",subjects+["CSS","JAVA Script"])
print("All data in the list * 2 : ",subjects*2)
print("Reverse value of list : ",subjects[-2])