from abc import ABC,abstractclassmethod
class Phone(ABC):
    name = ""
    def __init__(self,name):
        self.name = name
    @abstractclassmethod
    def display(cls):
        pass
class Meassage(Phone):
    def display(cls):
        print(cls.name+" is Messaged")
class Call(Phone):
    def display(cls):
        print(cls.name+" is Called")

ob1 = Meassage("Rahim")
ob1.display()
ob2 = Call("Karim")
ob2.display()

