#sum of 1^2+2^2+3^2+....+n^2
n = int(input("Enter last number : "))
sum = 0
number = range(1,n+1,1)
for x in number:
    sum = sum+x*x
print("Summation of the square series 1^2+2^2+3^2+....+ ",n,"^2 = ",sum)