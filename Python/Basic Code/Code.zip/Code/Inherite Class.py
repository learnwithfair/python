class teacher:
    name = ""
    age = ""
    id = ""
    def __init__(self,name,age,id):
        self.name = name
        self.age = age
        self.id = id
        self.display()
    def display(self):
        print("\nName : "+self.name+"\nAge : "+self.age+"\nID : "+self.id)
class student(teacher):
    gpa = ""
    def __init__(self,name,age,id,gpa):
        self.name = name
        self.age = age
        self.id = id
        self.gpa = gpa
        self.display()
        print("GPA : "+self.gpa+"\n")
anis = teacher("Anisul Islam","31","10101012")
rahat = student("Rahatul Islam","21","190609","3.92")