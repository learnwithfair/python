while True:
    text = input("Enter Any Letter : ")
    ch = text.lower()
    if ch == 'a' or ch == 'e' or ch == 'i' or ch == 'o' or ch == 'u':
        print("Vowel")
    else:
        print("Consonant")
