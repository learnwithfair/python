num1 = int(input("Enter First Number : "))
num2 = int(input("Enter Second Number : "))
# This is a Ternary Operator
print("Maximum Number is : ",num1 if num1>num2 else num2)