Stact = []
Stact.append("Rahatul Islam")
Stact.append("Suhanur Islam")
Stact.append("Anisul Islam")
print(Stact)
Stact.pop()# Stact is another called LIFO that means Last in Fast out
print(Stact)