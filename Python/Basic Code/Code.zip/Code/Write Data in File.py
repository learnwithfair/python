file = open("student details.txt","w")
file.write("Rahatul Islam")
file.close()