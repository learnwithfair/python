text = "This is Md Rahatul Islam."
List = text.split()
if not List:
    print("There is no value found")
print(List)
List.clear()
if not List:
    print("There is no value found")